import React, { useRef, useState } from "react";
import "../Contact us/Contact.css";
import { FaCheckCircle } from "react-icons/fa";
import { FaExclamationCircle } from "react-icons/fa";
import emailjs from "@emailjs/browser";

const Result = () => {
  return (
    <p> Your message has been sent successfully. We will contact you soon. </p>
  );
};

export default function Contact(props) {
  const [result, showResult] = useState(false);
  const form = useRef();

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm(
        "service_a9zozkg",
        "template_ujgky9n",
        form.current,
        "-X_SzLAhCKzBPt-CE"
      )
      .then(
        (result) => {
          console.log(result.text);
        },
        (error) => {
          console.log(error.text);
        }
      );
    e.target.reset();
    showResult(true);
  };
  //hide form submited text
  setTimeout(() => {
    showResult(false);
  }, 5000);

  return (
    <section className="contact" id="contact-us">
      <div className="container contact-us">
        <h2 className="section-title">Send us a message</h2>
        <p className="paragraph">
          When unknow printer took a gallery of type and scramblted it to make a
          type specimen book.
        </p>
        <div className="contact-body">
          <div className="contact-sec">
            <form ref={form} onSubmit={sendEmail}>
              <div className="form-control">
                <input
                  name="user_name"
                  type="text"
                  id="name"
                  className="contact-input"
                  onChange={nameChange}
                  placeholder="Name"
                />
                <FaCheckCircle />
                <FaExclamationCircle />
              </div>
              <div className="form-control">
                <input
                  name="user_email"
                  type="email"
                  id="email"
                  className="contact-input"
                  onChange={emailChange}
                  placeholder="Email"
                />
                <FaCheckCircle />
                <FaExclamationCircle />
              </div>
              <div className="form-control">
                <input
                  name="user_phone"
                  type="number"
                  id="phone"
                  className="contact-input"
                  onChange={phoneChange}
                  placeholder="Phone"
                />
                <FaCheckCircle />
                <FaExclamationCircle />
              </div>
              <div className="form-control">
                <select
                  className="contact-input"
                  title="Select Option"
                  name="user_dropDown"
                  required
                >
                  <option value="">Choose Service</option>
                  <option value="1">Ecommerce Development</option>
                  <option value="2">Wordpress Development</option>
                  <option value="3">Website Speed Optimization</option>
                  <option value="4">Web Design</option>
                  <option value="5">Search Engine Optimization(SEO)</option>
                </select>
              </div>
              <div className="form-control">
                <textarea
                  name="message"
                  id="message"
                  className="contact-message"
                  onChange={messageChange}
                  placeholder="Message"
                ></textarea>
                <FaCheckCircle />
                <FaExclamationCircle />
              </div>
              <input
                type="submit"
                className="contact-submit"
                value="Submit Now"
              />
              <div className="row"> {result ? <Result /> : null} </div>
            </form>
          </div>
          <div className="map">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d111256.75033969717!2d71.61997113257036!3d29.37692199958798!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x393b90c46c611ad5%3A0xfcdf0da8e103f862!2sBahawalpur%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1661296535757!5m2!1sen!2s"
              title="Map"
              frameBorder="0"
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
}

function nameChange() {
  const Name = document.getElementById("name");
  if (Name.value.trim() !== "") {
    setSuccess(Name, "inp");
  } else {
    setError(Name, "inp");
  }
}

function emailChange() {
  const Email = document.getElementById("email");
  if (validateEmail(Email) === true) {
    setSuccess(Email, "inp");
  } else {
    setError(Email, "inp");
  }
}

function phoneChange() {
  const Phone = document.getElementById("phone");
  if (Phone.value.trim() !== "") {
    setSuccess(Phone, "inp");
  } else {
    setError(Phone, "inp");
  }
}

function messageChange() {
  const Message = document.getElementById("message");
  if (Message.value.trim() !== "") {
    setSuccess(Message, "textarea");
  } else {
    setError(Message, "textarea");
  }
}

function setSuccess(input, inp_type) {
  const form_control = input.parentElement;
  if (inp_type === "textarea") {
    form_control.className = "form-control msg success";
  } else {
    form_control.className = "form-control success";
  }
}

function setError(input, inp_type) {
  const form_control = input.parentElement;
  if (inp_type === "textarea") {
    form_control.className = "form-control msg error";
  } else {
    form_control.className = "form-control error";
  }
}

function validateEmail(input) {
  var validRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (input.value.match(validRegex)) {
    return true;
  } else {
    return false;
  }
}
