import React from "react";
import "../Footer/Footer.css";
import { LinkButton } from "../Sub Components/btn_components";
import Logo from "../Images/grazez.png";
import { FaPhone, FaWhatsapp } from "react-icons/fa";
import { FaEnvelope } from "react-icons/fa";
import { FaMapMarkerAlt } from "react-icons/fa";
// import { FaWhatsapp } from "react-icons/fa";
import { FaBehance } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";

export function Footer() {
  return (
    <div>
      <footer className="footer">
        <FooterCta />
        <div className="container footer-body">
          <div className="footer-sec">
            <img src={Logo} alt="" />
            <p>
              Grazez is not just a web development agency. Grazez is the best
              web development agency in the town.
            </p>
            <div className="footer-social">
              <a href="https://wa.me/%2B923171939733?text=Hi%20Grazez%2C%20I%20want%20to%20discuss%20about%20my%20project.">
                {" "}
                <FaWhatsapp />{" "}
              </a>
              <a href="https://www.linkedin.com/in/graze-services-61762420b">
                {" "}
                <FaLinkedin />{" "}
              </a>
              <a href="https://www.behance.net/Graze-Services">
                {" "}
                <FaBehance />{" "}
              </a>
            </div>
          </div>

          <div className="footer-sec">
            <h4>Links</h4>
            <ul>
              <li>
                <a href="#about-us">About Us</a>
              </li>
              <li>
                <a href="#services">Services</a>
              </li>
              <li>
                <a href="#portfolio">Portfolios</a>
              </li>
              <li>
                <a href="#contact-us">Contact Us</a>
              </li>
            </ul>
          </div>

          <div className="footer-sec contact-icon">
            <h4>Contact Us</h4>
            <div className="footer-icon-part">
              <FaPhone />
              <a href="tel: +923171939733">03171939733</a>
            </div>
            <div className="footer-icon-part">
              <FaEnvelope />
              <a href="mailto: sakib75.cse@gmail.com">
                grazeservices@gmail.com
              </a>
            </div>
            <div className="footer-icon-part">
              <FaMapMarkerAlt />
              <span>Punjab, Pakistan</span>
            </div>
          </div>
        </div>
      </footer>

      <div className="copyright">
        <p>
          Copyright © 2022 <span>Grazez</span>. All rights reserved.
        </p>
      </div>
    </div>
  );
}

export function FooterCta() {
  return (
    <div className="footer-cta-section">
      <div className="footer-cta-body">
        <div className="cta-text">
          <h3>Have Any Query in Mind ?</h3>
          <p>
            If you have any query about your project you can contact now. We'll
            discuss your project and provide you the best possible solution.
          </p>
        </div>
        <div className="white-link-btn">
          <LinkButton
            button_title="Chat Now"
            link="https://wa.me/%2B923171939733?text=Hi%20Grazez%2C%20I%20want%20to%20discuss%20about%20my%20project."
          />
        </div>
      </div>
    </div>
  );
}
