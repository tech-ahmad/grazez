import React from "react";
import "../Services/Services.css";
import service1_img from "../Images/coding.png";
import service2_img from "../Images/wordpress.png";
import service3_img from "../Images/ecommerce.png";
import { ReadMore } from "../Sub Components/btn_components";

export default function Services() {
  return (
    <section className="container services-section" id="services">
      <h2 className="section-title center">Our Service</h2>
      <p className="paragraph center">
        Create a visual impact with our user-friendly website development
        services
      </p>

      <div className="services-block">
        <div className="service-item">
          <img src={service1_img} alt="" />
          <p className="service-title">Web Development</p>
          <p className="paragraph">
            Dynamic web design & web development services is a way of making a
            single website that works effectively on both desktop browsers and
            the myriad of mobile devices on the market.
          </p>
          {/* <ReadMore link="#" /> */}
        </div>

        <div className="service-item">
          <img src={service2_img} alt="" />
          <p className="service-title">Wordpress Development</p>
          <p className="paragraph">
            Wordpress is a popular Content Management System (CMS). It's easy to
            manage website content using wordpress. We provide professional
            wordpress development services to our customers
          </p>
          {/* <ReadMore link="#"/> */}
        </div>

        <div className="service-item">
          <img src={service3_img} alt="" />
          <p className="service-title">E-Commerce Websites</p>
          <p className="paragraph">
            Grazez provides user-friendly eCommerce store solutions according to
            requirements and search comfort of your target customers, making
            online shopping a remarkable and comfortable experience.
          </p>
          {/* <ReadMore link="#"/> */}
        </div>
      </div>
    </section>
  );
}
