import React from "react";
import "../Completed Work/Completed-work.css";
import achivment1 from "../Images/achivment1.png";
import achivment2 from "../Images/achivment2.png";
import achivment3 from "../Images/achivment3.png";
import achivment4 from "../Images/achivment4.png";

export default function Completed_work() {
  return (
    <section className="completed-work-sec">
      <div className="container completed-work-body">
        <div className="completed-work-text">
          <h2 className="section-title">
            Over 30+ Completed work & Still Counting
          </h2>
          <p className="paragraph">
            We provides the Best web Development serivces in the town which
            provides web and mobile application solutions with high quality
            interface and layout etc. We have core experience in the Wordpress
            development, web designing & development, online payment
            integration, e-commerce solution, SEO services all above had made us
            the markets top globally.
          </p>
          <p className="paragraph">
            We offer website design services to boost your business and help you
            in a highly competitive world.
          </p>
        </div>
        <div className="achivment-wrapper">
          <div className="achivment achivment1">
            <img src={achivment1} alt="" />
            <h3>30+</h3>
            <p>Projects Done</p>
          </div>
          <div className="achivment achivment2">
            <img src={achivment2} alt="" />
            <h3>25+</h3>
            <p>Happy Clients</p>
          </div>
          <div className="achivment achivment3">
            <img src={achivment3} alt="" />
            <h3>2+</h3>
            <p>Active Projects</p>
          </div>
          <div className="achivment achivment4">
            <img src={achivment4} alt="" />
            <h3>3+</h3>
            <p>Years Exerience</p>
          </div>
        </div>
      </div>
    </section>
  );
}
