import React from "react";
import "../Hire Us/Hire-us.css";
import Hireusimg from "../Images/Hire-us-img.png";
import { LinkButton } from "../Sub Components/btn_components";

export default function Hire_us() {
  return (
    <section className="Hire-us-section" id="about-us">
      <div className="container Hire-us-body">
        <img src={Hireusimg} alt="" />
        <div className="Hire-us-text">
          <h2 className="section-title">Why You Hire Us?</h2>
          <p className="paragraph">
            We believe that the design process must always consider how people
            use things in real life and lead to solutions that are clear,
            honest, and genuinely useful.
          </p>
          <p className="paragraph">
            People don’t just stumble into our office—it is through a conscious,
            concerted effort to find the best web developers. If you want your
            website to stand out from the competition, you need a stand-out
            design company.
          </p>
          <p className="paragraph">
            If you are looking for a creative company that can skyrocket your
            business to new heights, look no further.
          </p>

          <LinkButton button_title="Hire Now" link="#contact-us" />
        </div>
      </div>
    </section>
  );
}
