import portfolio_1 from "../Images/portfolio_1.png";
import portfolio_2 from "../Images/portfolio_2.png";
import portfolio_3 from "../Images/portfolio_3.png";
import portfolio_4 from "../Images/portfolio_4.png";
import portfolio_5 from "../Images/portfolio_5.png";

const projectsData = [
  {
    image: <img src={portfolio_4} alt="" />,
    title: "Electronics Shop",
    tag: "Ecommerce"
  },

  {
    image: <img src={portfolio_2} alt="" />,
    title: "Real Estate website",
    tag: "Wordpress"
  },
  {
    image: <img src={portfolio_3} alt="" />,
    title: "Dentist Website",
    tag: "Wordpress"
  },
  {
    image: <img src={portfolio_5} alt="" />,
    title: "School Website",
    tag: "Wordpress"
  },
  {
    image: <img src={portfolio_1} alt="" />,
    title: "Laptop Store",
    tag: "Ecommerce"
  }

  //   {
  //     image: <img src={portfolio_2} alt="" />,
  //     title: "Web Design 2",
  //     tag: "Web Design"
  //   },
  //   {
  //     image: <img src={portfolio_1} alt="" />,
  //     title: "Web Design 3",
  //     tag: "Web Design"
  //   },
  //   {
  //     image: <img src={portfolio_3} alt="" />,
  //     title: "Apps Design",
  //     tag: "Web Design"
  //   },
  //   {
  //     image: <img src={portfolio_2} alt="" />,
  //     title: "Digital Marketing 1",
  //     tag: "Marketing"
  //   },
  //   {
  //     image: <img src={portfolio_3} alt="" />,
  //     title: "Digital Marketing 2",
  //     tag: "Marketing"
  //   },
  //   {
  //     image: <img src={portfolio_1} alt="" />,
  //     title: "Digital Marketing 3",
  //     tag: "Marketing"
  //   }
];

export default projectsData;
